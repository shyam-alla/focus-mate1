FOCUS MATE ACCOUNT + CLOUD STORAGE SETUP

Files:
- focus_mate_updated_demo.html: updated single-file demo with email/password + Google sign-in UI and Supabase cloud-data integration.
- focus_mate_supabase_setup.sql: database table and row-level security policies.

IMPORTANT: Real accounts and cross-device cloud sync will not work until you configure your own Supabase project. The HTML file is a template, not a deployed backend.

1. Create a free project at https://supabase.com/.
2. In Supabase, open Project Settings > API (or Connect) and copy the Project URL and anon/publishable key.
3. Open focus_mate_updated_demo.html in a text editor. Find:
   const SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
   const SUPABASE_ANON_KEY = 'PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE';
   Replace the placeholder values with your own Project URL and anon/publishable key.
   NEVER put a service_role/secret key in browser HTML.
4. In Supabase > SQL Editor, run the contents of focus_mate_supabase_setup.sql.
5. In Supabase > Authentication > URL Configuration, add your published website URL to Site URL and Redirect URLs. During local testing, add the exact local/dev URL if appropriate.
6. In Supabase > Authentication > Providers, enable Email. Choose whether email confirmation is required.
7. For Google sign-in, enable Google in Authentication > Providers and enter the Google OAuth Client ID and Client Secret from Google Cloud Console. Add the Supabase callback URL shown by Supabase to the Google OAuth client's authorized redirect URIs. Save the configuration.
8. Upload the configured HTML file (renamed index.html) to your static host, or integrate it into your existing website. Keep the SQL file private to your setup; it does not contain secrets.

The demo stores notes, ideas, app-limit preferences, goals, and practice responses as per-user JSON records in Supabase. Browser storage is still used for local preview/cache. App time limits shown here are demo preferences and do not block other apps on a device; that requires native OS-level integration.

Security: Row-level security ensures each signed-in user can access only rows with their own auth user ID. Do not disable RLS or use a service-role key in frontend code.
