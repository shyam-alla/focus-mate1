-- Run this in Supabase Dashboard > SQL Editor > New query.
create table if not exists public.focus_mate_user_data (
  user_id uuid not null references auth.users(id) on delete cascade,
  data_key text not null,
  data_value jsonb not null default 'null'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, data_key)
);

alter table public.focus_mate_user_data enable row level security;

drop policy if exists "Users can read their own Focus Mate data" on public.focus_mate_user_data;
create policy "Users can read their own Focus Mate data"
  on public.focus_mate_user_data for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own Focus Mate data" on public.focus_mate_user_data;
create policy "Users can insert their own Focus Mate data"
  on public.focus_mate_user_data for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own Focus Mate data" on public.focus_mate_user_data;
create policy "Users can update their own Focus Mate data"
  on public.focus_mate_user_data for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own Focus Mate data" on public.focus_mate_user_data;
create policy "Users can delete their own Focus Mate data"
  on public.focus_mate_user_data for delete
  using (auth.uid() = user_id);
